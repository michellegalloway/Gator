#ifndef GATORCALIBSCR_H
#define GATORCALIBSCR_H

#include <string>

int GatorCalibScript(string calibset, string configfile, bool recreate=false);




#endif